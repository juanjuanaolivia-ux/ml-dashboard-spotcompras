@echo off
REM AGENTE SPOTCOMPRAS - Ejecutador
REM Este archivo ejecuta el descargador de datos de Mercado Libre

echo.
echo ================================================================================
echo 🤖 AGENTE SPOTCOMPRAS - DESCARGADOR DE DATOS
echo ================================================================================
echo.

REM Verificar si Python está instalado
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ ERROR: Python no está instalado o no está en el PATH
    echo.
    echo Por favor instala Python desde: https://www.python.org
    echo.
    pause
    exit /b 1
)

REM Verificar si requests está instalado
python -m pip show requests >nul 2>&1
if %errorlevel% neq 0 (
    echo ⚠️  Instalando dependencias necesarias...
    echo.
    python -m pip install requests
    if %errorlevel% neq 0 (
        echo ❌ Error al instalar dependencias
        pause
        exit /b 1
    )
)

REM Ejecutar el agente
echo 🚀 Iniciando agente...
echo.

python "%~dp0descargador_ml_spotcompras.py" "%~dp0"

echo.
pause
