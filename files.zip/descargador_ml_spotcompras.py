#!/usr/bin/env python3
"""
AGENTE SPOTCOMPRAS - Descargador de Datos ML
Ejecutar en tu computadora para descargar TODOS tus datos de Mercado Libre
"""

import webbrowser
import json
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse
import requests
import sys
import os

# CONFIGURACIÓN
CLIENT_ID = "1158178298754011"
CLIENT_SECRET = "VV4DeUGV2C54GyK2LIgXznulWDuDJHT6"
REDIRECT_URL = "http://localhost:8888/callback"

class CallbackHandler(BaseHTTPRequestHandler):
    """Maneja el callback de OAuth"""
    
    auth_code = None
    
    def do_GET(self):
        """Procesa el callback de ML"""
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        
        if "code" in params:
            CallbackHandler.auth_code = params["code"][0]
            
            # Enviar respuesta al navegador
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()
            
            html = """
            <html>
            <head><title>Autorización Completada</title></head>
            <body style="font-family: Arial; text-align: center; padding: 50px;">
                <h1>✅ ¡Autorización Completada!</h1>
                <p>Ya puedes cerrar esta ventana. El agente está descargando tus datos...</p>
                <p style="color: #999;">Vuelve a la terminal/consola para ver el progreso</p>
            </body>
            </html>
            """
            self.wfile.write(html.encode())
        else:
            self.send_error(400, "No authorization code received")
    
    def log_message(self, format, *args):
        """Silenciar logs del servidor"""
        pass

def get_authorization_code():
    """Obtiene el código de autorización de ML"""
    
    auth_url = (
        f"https://auth.mercadolibre.com.ar/authorization?"
        f"response_type=code&"
        f"client_id={CLIENT_ID}&"
        f"redirect_uri={urllib.parse.quote(REDIRECT_URL, safe='')}&"
        f"state=spotcompras_agente"
    )
    
    print("\n🔐 PASO 1: AUTORIZACIÓN EN MERCADO LIBRE")
    print("=" * 80)
    print(f"\n📱 Abriendo navegador para autorizar...\n")
    
    # Abrir navegador
    webbrowser.open(auth_url)
    
    # Esperar callback
    server = HTTPServer(('localhost', 8888), CallbackHandler)
    print("⏳ Esperando autorización (30 segundos máximo)...\n")
    
    server.timeout = 30
    server.handle_request()
    server.server_close()
    
    if CallbackHandler.auth_code:
        print(f"✅ Código recibido: {CallbackHandler.auth_code[:20]}...\n")
        return CallbackHandler.auth_code
    else:
        print("❌ No se recibió código de autorización\n")
        return None

def get_access_token(auth_code):
    """Intercambia el código por un access token"""
    
    print("🔐 PASO 2: OBTENER ACCESS TOKEN")
    print("=" * 80)
    
    url = "https://api.mercadolibre.com/oauth/token"
    data = {
        "grant_type": "authorization_code",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "code": auth_code,
        "redirect_uri": REDIRECT_URL
    }
    
    try:
        response = requests.post(url, data=data, timeout=10)
        response.raise_for_status()
        
        token_data = response.json()
        access_token = token_data.get("access_token")
        
        if access_token:
            print(f"✅ Token obtenido correctamente\n")
            return access_token
        else:
            print(f"❌ Error: {token_data}\n")
            return None
            
    except Exception as e:
        print(f"❌ Error: {e}\n")
        return None

def download_data(access_token):
    """Descarga TODOS los datos de ML"""
    
    print("📥 PASO 3: DESCARGANDO DATOS DE ML")
    print("=" * 80)
    
    headers = {"Authorization": f"Bearer {access_token}"}
    all_data = {}
    
    # 1. Info del usuario
    print("\n1️⃣  Usuario...", end=" ", flush=True)
    try:
        resp = requests.get("https://api.mercadolibre.com/users/me", headers=headers, timeout=10)
        resp.raise_for_status()
        all_data['user'] = resp.json()
        print("✅")
    except Exception as e:
        print(f"❌ {e}")
        return None
    
    # 2. Órdenes
    print("2️⃣  Órdenes...", end=" ", flush=True)
    try:
        params = {
            "seller": all_data['user']['id'],
            "limit": 100,
            "sort": "date_desc"
        }
        resp = requests.get(
            "https://api.mercadolibre.com/orders/search",
            headers=headers,
            params=params,
            timeout=15
        )
        resp.raise_for_status()
        all_data['orders'] = resp.json().get('results', [])
        print(f"✅ ({len(all_data['orders'])} encontradas)")
    except Exception as e:
        print(f"⚠️  Continuando...")
        all_data['orders'] = []
    
    # 3. Publicaciones
    print("3️⃣  Publicaciones...", end=" ", flush=True)
    try:
        resp = requests.get(
            f"https://api.mercadolibre.com/users/{all_data['user']['id']}/listings",
            headers=headers,
            timeout=10
        )
        resp.raise_for_status()
        all_data['listings'] = resp.json()
        print(f"✅ ({len(all_data['listings'])} encontradas)")
    except Exception as e:
        print(f"⚠️  Continuando...")
        all_data['listings'] = []
    
    # 4. Reputación del vendedor
    print("4️⃣  Reputación...", end=" ", flush=True)
    try:
        resp = requests.get(
            f"https://api.mercadolibre.com/users/{all_data['user']['id']}/seller_reputation",
            headers=headers,
            timeout=10
        )
        resp.raise_for_status()
        all_data['reputation'] = resp.json()
        print("✅")
    except Exception as e:
        print(f"⚠️  Continuando...")
    
    print(f"\n✅ Descarga completada\n")
    
    return all_data

def save_data(data, output_dir):
    """Guarda los datos en un archivo JSON"""
    
    print("💾 PASO 4: GUARDANDO DATOS")
    print("=" * 80)
    
    # Crear directorio si no existe
    os.makedirs(output_dir, exist_ok=True)
    
    filename = os.path.join(output_dir, f"spotcompras_datos_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"\n✅ Datos guardados en: {filename}\n")
        return filename
        
    except Exception as e:
        print(f"❌ Error al guardar: {e}\n")
        return None

def main():
    """Flujo principal"""
    
    # Obtener ruta de salida (por defecto Desktop)
    if len(sys.argv) > 1:
        output_dir = sys.argv[1]
    else:
        # Usar Desktop como default
        home = os.path.expanduser("~")
        output_dir = os.path.join(home, "Desktop", "Dashboard", "agente")
    
    print("\n" + "=" * 80)
    print("🤖 AGENTE SPOTCOMPRAS - DESCARGADOR DE DATOS MERCADO LIBRE")
    print("=" * 80)
    print(f"\n📁 Directorio de salida: {output_dir}\n")
    
    # Paso 1: Autorización
    auth_code = get_authorization_code()
    if not auth_code:
        print("❌ No se pudo obtener autorización")
        return
    
    # Paso 2: Access Token
    access_token = get_access_token(auth_code)
    if not access_token:
        print("❌ No se pudo obtener access token")
        return
    
    # Paso 3: Descargar datos
    data = download_data(access_token)
    if not data:
        print("❌ No se pudieron descargar datos")
        return
    
    # Paso 4: Guardar
    filename = save_data(data, output_dir)
    
    # Resumen
    if filename:
        print("=" * 80)
        print("🎉 ¡ÉXITO!")
        print("=" * 80)
        print(f"\n✅ Datos descargados exitosamente")
        print(f"📁 Archivo: {filename}")
        print(f"👤 Usuario: {data['user']['nickname']}")
        print(f"📦 Órdenes: {len(data['orders'])}")
        print(f"🏷️  Publicaciones: {len(data['listings'])}")
        print(f"\n📤 Ahora comparte este archivo con Claude")
        print(f"   para generar reportes automáticos\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n❌ Cancelado por el usuario")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
