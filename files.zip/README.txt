================================================================================
🤖 AGENTE SPOTCOMPRAS - DESCARGADOR DE DATOS MERCADO LIBRE
================================================================================

¿QUÉ HACE?
----------
Este agente descarga TODOS tus datos de Mercado Libre:
✅ Órdenes y ventas
✅ Publicaciones y stock
✅ Reputación del vendedor
✅ Datos de tus clientes

¿CÓMO USAR?
-----------

OPCIÓN 1: Windows (MÁS FÁCIL)
1. Haz doble click en: ejecutar_agente.bat
2. Se abrirá tu navegador pidiendo autorizar
3. Clickeá "Permitir" en Mercado Libre
4. Los datos se descargan automáticamente en esta carpeta

OPCIÓN 2: Terminal/CMD
1. Abre una terminal (cmd o PowerShell)
2. Navega a esta carpeta
3. Ejecuta: python descargador_ml_spotcompras.py
4. Sigue los pasos

¿QUÉ SUCEDE?
-----------
1. Se abre tu navegador con Mercado Libre
2. Vos clickeás "Permitir" (una sola vez)
3. El agente descarga todos tus datos
4. Se guarda un archivo JSON con toda la info
5. Vos lo compartís con Claude para hacer reportes

IMPORTANTE
----------
⚠️  Necesitas tener Python instalado
   Descargá desde: https://www.python.org

📝 El archivo JSON generado contiene datos sensibles
   No lo compartas con nadie que no sea de confianza

PROBLEMAS
---------
¿No se abre el navegador?
  → Intenta copiar la URL manualmente en tu navegador

¿Error "Puerto 8888 en uso"?
  → Cierra otras aplicaciones que usen ese puerto

¿No se descarga nada?
  → Revisa que tengas conexión a Internet
  → Revisa la consola para ver el error exacto

SOPORTE
-------
Si hay problemas, contacta a Claude con el error que aparece en la terminal.

================================================================================
Creado por: Agente Claude para SPOTCOMPRAS
Fecha: 2026-05-15
================================================================================
